package com.aiaimPro

import kotlin.math.*

data class ShotResult(
    val trajectory: Trajectory,
    val successRate: Int,
    val note: String
)

object BestShotSuggester {

    fun findBestShot(balls: List<Ball>, pockets: List<Pocket>): ShotResult? {
        val cueBall = balls.find { it.number == 0 } ?: return null
        val targetBalls = balls.filter { it.number > 0 && it.number != -1 }
        if (targetBalls.isEmpty()) return null

        var bestResult: ShotResult? = null
        var bestScore = Float.MAX_VALUE

        for (target in targetBalls) {
            for (pocket in pockets) {
                val obstacles = countObstacles(cueBall, target, balls)
                val distCue = distance(cueBall.x, cueBall.y, target.x, target.y)
                val distTarget = distance(target.x, target.y, pocket.x, pocket.y)
                val angle = calculateAngle(cueBall, target, pocket)

                val score = distCue + distTarget + obstacles * 500f + (1f - cos(angle.toDouble()).toFloat()) * 200f

                if (score < bestScore) {
                    bestScore = score
                    val traj = PhysicsEngine.buildTrajectory(cueBall, target, pocket, balls)
                    val successRate = calculateSuccessRate(distCue, distTarget, obstacles, angle)
                    val note = buildNote(distTarget, obstacles)
                    bestResult = ShotResult(traj, successRate, note)
                }
            }
        }

        return bestResult
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        return sqrt((x2 - x1).pow(2) + (y2 - y1).pow(2))
    }

    private fun countObstacles(cueBall: Ball, target: Ball, allBalls: List<Ball>): Int {
        var count = 0
        for (ball in allBalls) {
            if (ball.number == 0 || ball.number == target.number) continue
            if (isOnLineSegment(cueBall.x, cueBall.y, target.x, target.y, ball.x, ball.y, ball.radius)) {
                count++
            }
        }
        return count
    }

    private fun isOnLineSegment(
        x1: Float, y1: Float, x2: Float, y2: Float,
        bx: Float, by: Float, br: Float
    ): Boolean {
        val dx = x2 - x1
        val dy = y2 - y1
        val len = sqrt(dx * dx + dy * dy)
        if (len == 0f) return false

        val nx = dx / len
        val ny = dy / len
        val proj = (bx - x1) * nx + (by - y1) * ny
        if (proj < 0 || proj > len) return false

        val closestX = x1 + proj * nx
        val closestY = y1 + proj * ny
        return sqrt((bx - closestX).pow(2) + (by - closestY).pow(2)) < br + 15f
    }

    private fun calculateAngle(cueBall: Ball, target: Ball, pocket: Pocket): Float {
        val a1 = atan2((target.y - cueBall.y).toDouble(), (target.x - cueBall.x).toDouble())
        val a2 = atan2((pocket.y - target.y).toDouble(), (pocket.x - target.x).toDouble())
        return abs((a2 - a1).toFloat())
    }

    private fun calculateSuccessRate(
        distCue: Float, distTarget: Float,
        obstacles: Int, angle: Float
    ): Int {
        var rate = 100
        rate -= (distCue / 10).toInt().coerceAtMost(30)
        rate -= (distTarget / 10).toInt().coerceAtMost(20)
        rate -= obstacles * 25
        rate -= (Math.toDegrees(angle.toDouble()) / 5).toInt().coerceAtMost(20)
        return rate.coerceIn(5, 99)
    }

    private fun buildNote(distTarget: Float, obstacles: Int): String {
        return when {
            obstacles > 0 -> "⚠️ يوجد $obstacles عائق في المسار"
            distTarget < 200 -> "✅ قريبة من الحفرة"
            distTarget < 400 -> "📝 مسافة متوسطة"
            else -> "📐 مسافة بعيدة"
        }
    }
}
