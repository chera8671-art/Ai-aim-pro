package com.aiaimPro

import android.content.Context
import android.graphics.*
import android.view.View

class OverlayRenderer(context: Context) : View(context) {

    private var balls: List<Ball> = emptyList()
    private var pockets: List<Pocket> = emptyList()
    private var trajectory: Trajectory? = null
    private var message: String? = null
    private var messageTimer = 0L

    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val ballBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 2f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 20f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val trajectoryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }
    private val bouncePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.CYAN
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(15f, 10f), 0f)
    }
    private val ghostBallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED
        alpha = 120
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val targetPathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF88")
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
    }
    private val messagePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 36f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val messageBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        alpha = 180
    }

    fun updateData(balls: List<Ball>, pockets: List<Pocket>) {
        this.balls = balls
        this.pockets = pockets
        postInvalidate()
    }

    fun updateTrajectory(traj: Trajectory?) {
        this.trajectory = traj
        postInvalidate()
    }

    fun showMessage(msg: String) {
        message = msg
        messageTimer = System.currentTimeMillis()
        postInvalidate()
        postDelayed({ message = null; postInvalidate() }, 3000)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        drawTrajectory(canvas)
        drawBalls(canvas)
        drawMessage(canvas)
    }

    private fun drawBalls(canvas: Canvas) {
        for (ball in balls) {
            ballPaint.color = ball.color
            canvas.drawCircle(ball.x, ball.y, ball.radius, ballPaint)
            canvas.drawCircle(ball.x, ball.y, ball.radius, ballBorderPaint)

            if (ball.number > 0) {
                val numStr = ball.number.toString()
                textPaint.color = if (ball.color == Color.YELLOW || ball.color == Color.WHITE) Color.BLACK else Color.WHITE
                canvas.drawText(numStr, ball.x, ball.y + 7f, textPaint)
            }
        }
    }

    private fun drawTrajectory(canvas: Canvas) {
        val traj = trajectory ?: return

        // Draw cue ball path
        for (i in 0 until traj.cuePath.size - 1) {
            val start = traj.cuePath[i]
            val end = traj.cuePath[i + 1]
            val paint = if (i == 0) trajectoryPaint else bouncePaint
            canvas.drawLine(start.x, start.y, end.x, end.y, paint)
        }

        // Draw ghost ball
        val ballRadius = traj.targetBall?.radius ?: 20f
        canvas.drawCircle(traj.ghostBallX, traj.ghostBallY, ballRadius, ghostBallPaint)

        // Draw target path
        if (traj.targetPath.size >= 2) {
            val tp = traj.targetPath
            canvas.drawLine(tp[0].x, tp[0].y, tp[1].x, tp[1].y, targetPathPaint)
        }
    }

    private fun drawMessage(canvas: Canvas) {
        val msg = message ?: return
        val cx = width / 2f
        val cy = height * 0.15f

        val rect = RectF(cx - 300f, cy - 40f, cx + 300f, cy + 20f)
        canvas.drawRoundRect(rect, 12f, 12f, messageBgPaint)
        canvas.drawText(msg, cx, cy + 8f, messagePaint)
    }
}
