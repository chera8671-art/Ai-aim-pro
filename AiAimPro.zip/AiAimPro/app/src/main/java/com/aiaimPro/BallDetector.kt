package com.aiaimPro

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

data class Ball(
    val x: Float,
    val y: Float,
    val radius: Float,
    val number: Int,
    val color: Int
)

data class Pocket(val x: Float, val y: Float)

object BallDetector {

    fun detectBalls(bitmap: Bitmap): List<Ball> {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)

        val gray = Mat()
        Imgproc.cvtColor(mat, gray, Imgproc.COLOR_BGR2GRAY)
        Imgproc.GaussianBlur(gray, gray, Size(9.0, 9.0), 2.0, 2.0)

        val circles = Mat()
        Imgproc.HoughCircles(
            gray, circles, Imgproc.HOUGH_GRADIENT,
            1.0, 30.0, 100.0, 30.0, 15.0, 40.0
        )

        val balls = mutableListOf<Ball>()

        if (!circles.empty()) {
            for (i in 0 until circles.cols()) {
                val data = circles.get(0, i)
                val x = data[0].toFloat()
                val y = data[1].toFloat()
                val r = data[2].toFloat()

                val number = identifyBallNumber(bitmap, x.toInt(), y.toInt())
                val color = getBallColor(number)
                balls.add(Ball(x, y, r, number, color))
            }
        }

        mat.release()
        gray.release()
        circles.release()

        return balls
    }

    private fun identifyBallNumber(bitmap: Bitmap, cx: Int, cy: Int): Int {
        if (cx < 0 || cy < 0 || cx >= bitmap.width || cy >= bitmap.height) return -1

        val pixel = bitmap.getPixel(cx, cy)
        val r = android.graphics.Color.red(pixel)
        val g = android.graphics.Color.green(pixel)
        val b = android.graphics.Color.blue(pixel)

        // White ball
        if (r > 220 && g > 220 && b > 220) return 0
        // Yellow (1, 9)
        if (r > 200 && g > 180 && b < 80) return 1
        // Blue (2, 10)
        if (b > 180 && r < 100 && g < 100) return 2
        // Red (3, 11)
        if (r > 180 && g < 80 && b < 80) return 3
        // Purple (4, 12)
        if (r > 120 && b > 120 && g < 80) return 4
        // Orange (5, 13)
        if (r > 200 && g > 100 && g < 160 && b < 80) return 5
        // Green (6, 14)
        if (g > 150 && r < 100 && b < 100) return 6
        // Brown (7, 15)
        if (r > 120 && g > 60 && g < 120 && b < 60) return 7
        // Black (8)
        if (r < 50 && g < 50 && b < 50) return 8

        return -1
    }

    private fun getBallColor(number: Int): Int {
        return when (number) {
            0 -> android.graphics.Color.WHITE
            1, 9 -> android.graphics.Color.YELLOW
            2, 10 -> android.graphics.Color.BLUE
            3, 11 -> android.graphics.Color.RED
            4, 12 -> android.graphics.Color.parseColor("#800080") // Purple
            5, 13 -> android.graphics.Color.parseColor("#FFA500") // Orange
            6, 14 -> android.graphics.Color.GREEN
            7, 15 -> android.graphics.Color.parseColor("#8B4513") // Brown
            8 -> android.graphics.Color.BLACK
            else -> android.graphics.Color.GRAY
        }
    }

    fun detectPockets(bitmap: Bitmap): List<Pocket> {
        val w = bitmap.width.toFloat()
        val h = bitmap.height.toFloat()

        // 6 standard pool table pockets: 4 corners + 2 middle sides
        return listOf(
            Pocket(w * 0.03f, h * 0.05f),      // Top-left
            Pocket(w * 0.50f, h * 0.03f),       // Top-middle
            Pocket(w * 0.97f, h * 0.05f),       // Top-right
            Pocket(w * 0.03f, h * 0.95f),       // Bottom-left
            Pocket(w * 0.50f, h * 0.97f),       // Bottom-middle
            Pocket(w * 0.97f, h * 0.95f)        // Bottom-right
        )
    }
}
