package com.aiaimPro

import kotlin.math.*

data class Position(val x: Float, val y: Float, val timestamp: Long)

class TrajectoryTracker {

    private val positionHistory = ArrayDeque<Position>(10)
    private val MAX_HISTORY = 10

    fun addPosition(x: Float, y: Float) {
        if (positionHistory.size >= MAX_HISTORY) {
            positionHistory.removeFirst()
        }
        positionHistory.addLast(Position(x, y, System.currentTimeMillis()))
    }

    fun getSpeed(): Float {
        if (positionHistory.size < 2) return 0f
        val last = positionHistory.last()
        val prev = positionHistory[positionHistory.size - 2]
        val dt = (last.timestamp - prev.timestamp) / 1000f
        if (dt == 0f) return 0f

        val dx = last.x - prev.x
        val dy = last.y - prev.y
        return sqrt(dx * dx + dy * dy) / dt
    }

    fun getDirection(): Float {
        if (positionHistory.size < 2) return 0f
        val last = positionHistory.last()
        val prev = positionHistory[positionHistory.size - 2]
        return atan2((last.y - prev.y).toDouble(), (last.x - prev.x).toDouble()).toFloat()
    }

    fun predictFuturePositions(steps: Int = 5): List<Position> {
        if (positionHistory.size < 2) return emptyList()

        val speed = getSpeed()
        val direction = getDirection()
        val last = positionHistory.last()

        val vx = speed * cos(direction.toDouble()).toFloat() * 0.016f
        val vy = speed * sin(direction.toDouble()).toFloat() * 0.016f

        return (1..steps).map { step ->
            Position(
                last.x + vx * step,
                last.y + vy * step,
                last.timestamp + step * 16L
            )
        }
    }

    fun getConfidenceScore(): Float {
        if (positionHistory.size < 3) return 0f

        val directions = mutableListOf<Float>()
        for (i in 1 until positionHistory.size) {
            val p = positionHistory[i - 1]
            val c = positionHistory[i]
            directions.add(atan2((c.y - p.y).toDouble(), (c.x - p.x).toDouble()).toFloat())
        }

        if (directions.size < 2) return 0f

        var variance = 0f
        val mean = directions.average().toFloat()
        for (d in directions) {
            variance += (d - mean).pow(2)
        }
        variance /= directions.size

        // Lower variance = higher confidence
        return (1f - (variance / (Math.PI.toFloat().pow(2)))).coerceIn(0f, 1f)
    }

    fun isAboveConfidenceThreshold(): Boolean = getConfidenceScore() > 0.6f

    fun clear() = positionHistory.clear()
}
