package com.aiaimPro

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class AimAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed for screen overlay functionality
    }

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
    }
}
