package com.aiaimPro

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import android.view.*
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayRenderer: OverlayRenderer
    private lateinit var floatingMenu: FloatingMenuView
    private var mediaProjection: MediaProjection? = null
    private lateinit var screenCaptureService: ScreenCaptureService
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var isAnalyzing = false

    companion object {
        const val CHANNEL_ID = "AiAimProChannel"
        const val NOTIFICATION_ID = 1
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", -1) ?: -1
        val data = intent?.getParcelableExtra<Intent>("data")

        if (resultCode != -1 && data != null) {
            val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)
            screenCaptureService = ScreenCaptureService(this, mediaProjection!!)
            setupOverlay()
        }

        return START_STICKY
    }

    private fun setupOverlay() {
        val overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        overlayRenderer = OverlayRenderer(this)
        windowManager.addView(overlayRenderer, overlayParams)

        val menuParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 200
        }

        floatingMenu = FloatingMenuView(this, windowManager, menuParams) { action ->
            when (action) {
                "analyze" -> startAnalysis()
                "best_shot" -> findBestShot()
                "stop" -> stopSelf()
            }
        }
        windowManager.addView(floatingMenu, menuParams)

        startContinuousCapture()
    }

    private fun startContinuousCapture() {
        serviceScope.launch {
            while (isActive) {
                val bitmap = screenCaptureService.captureScreen()
                if (bitmap != null) {
                    val balls = BallDetector.detectBalls(bitmap)
                    val pockets = BallDetector.detectPockets(bitmap)
                    overlayRenderer.updateData(balls, pockets)
                }
                delay(1000)
            }
        }
    }

    private fun startAnalysis() {
        if (isAnalyzing) return
        isAnalyzing = true
        serviceScope.launch {
            val bitmap = screenCaptureService.captureScreen()
            if (bitmap != null) {
                val balls = BallDetector.detectBalls(bitmap)
                val pockets = BallDetector.detectPockets(bitmap)
                val cueBall = balls.find { it.number == 0 }
                if (cueBall != null) {
                    val trajectory = PhysicsEngine.calculateTrajectory(cueBall, balls, pockets)
                    overlayRenderer.updateTrajectory(trajectory)
                }
            }
            isAnalyzing = false
        }
    }

    private fun findBestShot() {
        serviceScope.launch {
            val bitmap = screenCaptureService.captureScreen()
            if (bitmap != null) {
                val balls = BallDetector.detectBalls(bitmap)
                val pockets = BallDetector.detectPockets(bitmap)
                val bestShot = BestShotSuggester.findBestShot(balls, pockets)
                if (bestShot != null) {
                    overlayRenderer.updateTrajectory(bestShot.trajectory)
                    overlayRenderer.showMessage("أفضل ضربة: نسبة النجاح ${bestShot.successRate}%")
                }
            }
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "AI Aim Pro",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "خدمة المساعد الذكي لألعاب البلياردو"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AI Aim Pro يعمل")
            .setContentText("المساعد الذكي نشط ✅")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        if (::overlayRenderer.isInitialized) windowManager.removeView(overlayRenderer)
        if (::floatingMenu.isInitialized) windowManager.removeView(floatingMenu)
        mediaProjection?.stop()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
