package com.aiaimPro

import kotlin.math.*

data class TrajectoryPoint(val x: Float, val y: Float)
data class Trajectory(
    val cuePath: List<TrajectoryPoint>,
    val targetPath: List<TrajectoryPoint>,
    val ghostBallX: Float,
    val ghostBallY: Float,
    val targetBall: Ball?,
    val targetPocket: Pocket?
)

object PhysicsEngine {

    private const val TABLE_LEFT = 0.05f
    private const val TABLE_RIGHT = 0.95f
    private const val TABLE_TOP = 0.05f
    private const val TABLE_BOTTOM = 0.95f
    private const val MAX_BOUNCES = 4

    fun calculateTrajectory(cueBall: Ball, allBalls: List<Ball>, pockets: List<Pocket>): Trajectory? {
        val targetBalls = allBalls.filter { it.number != 0 && it.number != -1 }
        if (targetBalls.isEmpty()) return null

        var bestTrajectory: Trajectory? = null
        var bestScore = Float.MAX_VALUE

        for (target in targetBalls) {
            for (pocket in pockets) {
                val score = calculateScore(cueBall, target, pocket, allBalls)
                if (score < bestScore) {
                    bestScore = score
                    bestTrajectory = buildTrajectory(cueBall, target, pocket, allBalls)
                }
            }
        }

        return bestTrajectory
    }

    fun buildTrajectory(cueBall: Ball, target: Ball, pocket: Pocket, allBalls: List<Ball>): Trajectory {
        // Direction from target to pocket
        val dx = pocket.x - target.x
        val dy = pocket.y - target.y
        val dist = sqrt(dx * dx + dy * dy)
        val nx = dx / dist
        val ny = dy / dist

        // Ghost ball position: behind target ball at radius*2
        val ghostX = target.x - nx * (target.radius * 2)
        val ghostY = target.y - ny * (target.radius * 2)

        // Cue ball path: from cue ball to ghost ball with bounces
        val cuePath = calculatePathWithBounces(cueBall.x, cueBall.y, ghostX, ghostY)

        // Target ball path: from target to pocket
        val targetPath = listOf(
            TrajectoryPoint(target.x, target.y),
            TrajectoryPoint(pocket.x, pocket.y)
        )

        return Trajectory(cuePath, targetPath, ghostX, ghostY, target, pocket)
    }

    private fun calculatePathWithBounces(
        startX: Float, startY: Float,
        endX: Float, endY: Float
    ): List<TrajectoryPoint> {
        val points = mutableListOf(TrajectoryPoint(startX, startY))
        var x = startX
        var y = startY
        var dx = endX - startX
        var dy = endY - startY

        for (bounce in 0 until MAX_BOUNCES) {
            val nextX = x + dx
            val nextY = y + dy

            // Check wall collisions and bounce
            var hitWall = false

            if (nextX < TABLE_LEFT * 1000 || nextX > TABLE_RIGHT * 1000) {
                dx = -dx
                hitWall = true
            }
            if (nextY < TABLE_TOP * 1000 || nextY > TABLE_BOTTOM * 1000) {
                dy = -dy
                hitWall = true
            }

            val clampedX = x + dx
            val clampedY = y + dy
            points.add(TrajectoryPoint(clampedX, clampedY))

            if (!hitWall) break
            x = clampedX
            y = clampedY
        }

        return points
    }

    private fun calculateScore(cueBall: Ball, target: Ball, pocket: Pocket, allBalls: List<Ball>): Float {
        val distCueToTarget = sqrt((target.x - cueBall.x).pow(2) + (target.y - cueBall.y).pow(2))
        val distTargetToPocket = sqrt((pocket.x - target.x).pow(2) + (pocket.y - target.y).pow(2))

        val obstacleCount = countObstacles(cueBall, target, allBalls)
        val obstacleScore = obstacleCount * 500f

        return distCueToTarget + distTargetToPocket + obstacleScore
    }

    private fun countObstacles(cueBall: Ball, target: Ball, allBalls: List<Ball>): Int {
        var count = 0
        for (ball in allBalls) {
            if (ball.number == 0 || ball.number == target.number) continue
            if (isOnPath(cueBall.x, cueBall.y, target.x, target.y, ball.x, ball.y, ball.radius)) {
                count++
            }
        }
        return count
    }

    private fun isOnPath(x1: Float, y1: Float, x2: Float, y2: Float,
                         bx: Float, by: Float, br: Float): Boolean {
        val dx = x2 - x1
        val dy = y2 - y1
        val len = sqrt(dx * dx + dy * dy)
        if (len == 0f) return false

        val nx = dx / len
        val ny = dy / len
        val tx = bx - x1
        val ty = by - y1
        val proj = tx * nx + ty * ny

        if (proj < 0 || proj > len) return false

        val closestX = x1 + proj * nx
        val closestY = y1 + proj * ny
        val dist = sqrt((bx - closestX).pow(2) + (by - closestY).pow(2))

        return dist < br + 15f
    }
}
