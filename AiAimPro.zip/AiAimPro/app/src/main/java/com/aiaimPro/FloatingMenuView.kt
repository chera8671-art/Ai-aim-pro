package com.aiaimPro

import android.content.Context
import android.graphics.Color
import android.view.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingMenuView(
    context: Context,
    private val windowManager: WindowManager,
    private val params: WindowManager.LayoutParams,
    private val onAction: (String) -> Unit
) : LinearLayout(context) {

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    init {
        orientation = VERTICAL
        setPadding(20, 20, 20, 20)
        setBackgroundColor(Color.parseColor("#CC000000"))

        val border = GradientDrawable()
        border.setStroke(3, Color.parseColor("#FFD700"))
        border.cornerRadius = 16f
        background = border

        val title = TextView(context).apply {
            text = "🎱 AI Aim Pro"
            setTextColor(Color.parseColor("#FFD700"))
            textSize = 16f
            setPadding(0, 0, 0, 12)
        }
        addView(title)

        addMenuButton("🔬 AI تحليل", "analyze")
        addMenuButton("🎯 أفضل ضربة", "best_shot")
        addMenuButton("❌ إغلاق", "stop")

        setOnTouchListener { _, event -> handleTouch(event) }
    }

    private fun addMenuButton(label: String, action: String) {
        val btn = Button(context).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#88333333"))
            setPadding(24, 16, 24, 16)
            textSize = 14f
            setOnClickListener { onAction(action) }
        }
        val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, 6, 0, 6)
        }
        addView(btn, lp)
    }

    private fun handleTouch(event: MotionEvent): Boolean {
        return when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = params.x
                initialY = params.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                true
            }
            MotionEvent.ACTION_MOVE -> {
                params.x = initialX + (event.rawX - initialTouchX).toInt()
                params.y = initialY + (event.rawY - initialTouchY).toInt()
                windowManager.updateViewLayout(this, params)
                true
            }
            else -> false
        }
    }

    private fun GradientDrawable() = android.graphics.drawable.GradientDrawable()
}
