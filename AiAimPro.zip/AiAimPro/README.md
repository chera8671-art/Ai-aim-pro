# AI Aim Pro — مساعد البلياردو الذكي 🎱

## كيفية فتح المشروع في Android Studio

1. **افتح Android Studio**
2. **File → Open** واختر مجلد `AiAimPro`
3. انتظر حتى ينتهي Gradle من المزامنة

## إضافة مكتبة OpenCV (مطلوب!)

1. حمّل OpenCV لـ Android من: https://opencv.org/releases/
2. اختر أحدث نسخة وحمّل `OpenCV-X.X.X-android-sdk.zip`
3. فك الضغط، ثم في Android Studio:
   - **File → New → Import Module**
   - اختر مجلد `sdk/java` من داخل ملف OpenCV المحمّل
   - سيُضاف كـ `:opencv` module
4. الملف `app/build.gradle` يحتوي بالفعل على:
   ```gradle
   implementation project(':opencv')
   ```

## بناء وتصدير APK

1. في Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. انتظر حتى ينتهي البناء
3. اضغط على "locate" في الإشعار أسفل الشاشة
4. ستجد الـ APK في: `app/build/outputs/apk/debug/app-debug.apk`

## كيفية استخدام التطبيق

1. **ثبّت** الـ APK على هاتفك
2. **افتح** التطبيق وامنح الصلاحيات:
   - اضغط زر **منح صلاحية الرسم** ✅
   - اضغط **تفعيل خدمة الوصول** ✅
3. اضغط **تشغيل المساعد الذكي** 🚀
4. **افتح لعبة 8 Ball Pool**
5. ستظهر القائمة العائمة فوق اللعبة
6. اضغط **AI تحليل** لتحليل الطاولة أو **أفضل ضربة** لاقتراح أفضل حركة

## الميزات

- 🔬 كشف الكرات بالذكاء الاصطناعي (OpenCV)
- 📐 حساب الارتدادات حتى 4 مرات
- 🎯 اقتراح أفضل ضربة تلقائياً
- 🖱️ اللمس يمر خلال الرسم للعب بشكل طبيعي
- 📊 نسب النجاح وكشف العوائق
